
import React from 'react';
import { AIInsight } from '../types';
import { Sparkles, AlertCircle, CheckCircle, Info } from 'lucide-react';

interface AIInsightBoxProps {
  insight: AIInsight | null;
  loading: boolean;
}

const AIInsightBox: React.FC<AIInsightBoxProps> = ({ insight, loading }) => {
  if (loading) {
    return (
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 animate-pulse">
        <div className="h-6 w-32 bg-slate-200 rounded mb-4"></div>
        <div className="h-4 w-full bg-slate-100 rounded mb-2"></div>
        <div className="h-4 w-full bg-slate-100 rounded mb-2"></div>
        <div className="h-4 w-3/4 bg-slate-100 rounded"></div>
      </div>
    );
  }

  if (!insight) return null;

  const statusIcons = {
    good: <CheckCircle className="text-emerald-500" />,
    warning: <AlertCircle className="text-amber-500" />,
    critical: <AlertCircle className="text-rose-500" />,
  };

  const statusColors = {
    good: 'bg-emerald-50 border-emerald-100',
    warning: 'bg-amber-50 border-amber-100',
    critical: 'bg-rose-50 border-rose-100',
  };

  return (
    <div className={`p-6 rounded-2xl border ${statusColors[insight.status]} shadow-sm transition-all duration-500`}>
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="text-indigo-600 w-5 h-5" />
        <h3 className="font-bold text-slate-800 text-lg">স্মার্ট এআই পরামর্শ</h3>
        <div className="ml-auto">{statusIcons[insight.status]}</div>
      </div>
      
      <p className="text-slate-700 mb-4 leading-relaxed">{insight.summary}</p>
      
      <div className="space-y-2">
        {insight.suggestions.map((s, i) => (
          <div key={i} className="flex items-start gap-2 bg-white/50 p-3 rounded-lg border border-white/20">
            <Info className="w-4 h-4 text-indigo-400 mt-1 flex-shrink-0" />
            <span className="text-sm text-slate-600">{s}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// Simple Lucide-style Icon Placeholders
const IconWrapper = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <span className={className}>{children}</span>
);

export default AIInsightBox;

// Mocking Lucide icons for simplicity without extra dependency installs if needed
const Sparkles = (props: any) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>;
const AlertCircle = (props: any) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>;
const CheckCircle = (props: any) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>;
const Info = (props: any) => <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>;
