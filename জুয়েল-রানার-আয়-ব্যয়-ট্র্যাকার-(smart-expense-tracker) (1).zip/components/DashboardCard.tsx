
import React from 'react';
import { BDT_SYMBOL } from '../constants';

interface DashboardCardProps {
  title: string;
  amount: number;
  subtitle?: string;
  variant?: 'primary' | 'success' | 'danger' | 'warning';
  className?: string;
}

const DashboardCard: React.FC<DashboardCardProps> = ({ title, amount, subtitle, variant = 'primary', className = '' }) => {
  const bgColors = {
    primary: 'bg-slate-800 text-white',
    success: 'bg-emerald-600 text-white',
    danger: 'bg-rose-600 text-white',
    warning: 'bg-amber-500 text-white',
  };

  return (
    <div className={`p-6 rounded-2xl shadow-lg transition-all duration-300 ${bgColors[variant]} ${className}`}>
      <h3 className="text-sm font-medium opacity-90 mb-1">{title}</h3>
      <div className="text-3xl font-bold">
        {BDT_SYMBOL} {amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
      </div>
      {subtitle && <p className="mt-2 text-xs opacity-80 font-medium italic">{subtitle}</p>}
    </div>
  );
};

export default DashboardCard;
