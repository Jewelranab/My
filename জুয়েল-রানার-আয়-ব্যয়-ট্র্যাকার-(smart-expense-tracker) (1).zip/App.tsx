
import React, { useState, useEffect, useCallback } from 'react';
import { Expense, UserSettings, AIInsight, BankAccount } from './types';
import { CATEGORIES, BDT_SYMBOL } from './constants';
import DashboardCard from './components/DashboardCard';
import SpendingChart from './components/SpendingChart';
import AIInsightBox from './components/AIInsightBox';
import { getFinancialInsights } from './services/geminiService';
import { Plus, Trash2, Settings, Wallet, CreditCard } from 'lucide-react';

const App: React.FC = () => {
  // State
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('expenses_v3');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [settings, setSettings] = useState<UserSettings>(() => {
    const saved = localStorage.getItem('settings_v3');
    return saved ? JSON.parse(saved) : { 
      banks: [{ id: 'default', name: 'নগদ ক্যাশ', balance: 0 }], 
      dailyLimit: 0 
    };
  });

  const [expenseName, setExpenseName] = useState('');
  const [expenseAmount, setExpenseAmount] = useState('');
  const [expenseCategory, setExpenseCategory] = useState(CATEGORIES[0]);
  const [selectedBankId, setSelectedBankId] = useState(settings.banks[0]?.id || 'default');
  
  const [showSettings, setShowSettings] = useState(false);
  const [newBankName, setNewBankName] = useState('');
  const [newBankBalance, setNewBankBalance] = useState('');
  const [newDailyLimit, setNewDailyLimit] = useState(settings.dailyLimit.toString());

  const [aiInsight, setAiInsight] = useState<AIInsight | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  // Persistence
  useEffect(() => {
    localStorage.setItem('expenses_v3', JSON.stringify(expenses));
    localStorage.setItem('settings_v3', JSON.stringify(settings));
  }, [expenses, settings]);

  // Calculations
  const today = new Date().toLocaleDateString();
  const todayTotal = expenses
    .filter(e => e.date === today)
    .reduce((sum, e) => sum + e.amount, 0);

  const totalBankBalance = settings.banks.reduce((sum, b) => sum + b.balance, 0);
  const isLimitExceeded = settings.dailyLimit > 0 && todayTotal > settings.dailyLimit;

  // Actions
  const addExpense = () => {
    const amountNum = parseFloat(expenseAmount);
    if (!expenseName || isNaN(amountNum) || amountNum <= 0 || !selectedBankId) return;

    // Check if bank has enough balance
    const bank = settings.banks.find(b => b.id === selectedBankId);
    if (!bank) return;

    const newExpense: Expense = {
      id: crypto.randomUUID(),
      name: expenseName,
      amount: amountNum,
      category: expenseCategory,
      bankId: selectedBankId,
      date: today
    };

    setExpenses(prev => [newExpense, ...prev]);
    setSettings(prev => ({
      ...prev,
      banks: prev.banks.map(b => b.id === selectedBankId ? { ...b, balance: b.balance - amountNum } : b)
    }));
    
    setExpenseName('');
    setExpenseAmount('');
    
    triggerAIUpdate([newExpense, ...expenses], { 
      ...settings, 
      banks: settings.banks.map(b => b.id === selectedBankId ? { ...b, balance: b.balance - amountNum } : b) 
    });
  };

  const deleteExpense = (id: string) => {
    const expToDelete = expenses.find(e => e.id === id);
    if (!expToDelete) return;

    setExpenses(prev => prev.filter(e => e.id !== id));
    setSettings(prev => ({
      ...prev,
      banks: prev.banks.map(b => b.id === expToDelete.bankId ? { ...b, balance: b.balance + expToDelete.amount } : b)
    }));
  };

  const addBank = () => {
    const balanceNum = parseFloat(newBankBalance);
    if (!newBankName || isNaN(balanceNum)) return;

    const newBank: BankAccount = {
      id: crypto.randomUUID(),
      name: newBankName,
      balance: balanceNum
    };

    setSettings(prev => ({
      ...prev,
      banks: [...prev.banks, newBank]
    }));
    setNewBankName('');
    setNewBankBalance('');
  };

  const deleteBank = (bankId: string) => {
    if (settings.banks.length <= 1) return;
    setSettings(prev => ({
      ...prev,
      banks: prev.banks.filter(b => b.id !== bankId)
    }));
    if (selectedBankId === bankId) setSelectedBankId(settings.banks[0].id);
  };

  const updateDailyLimit = () => {
    setSettings(prev => ({ ...prev, dailyLimit: parseFloat(newDailyLimit) || 0 }));
  };

  const triggerAIUpdate = useCallback(async (currentExpenses: Expense[], currentSettings: UserSettings) => {
    if (currentExpenses.length === 0) return;
    setAiLoading(true);
    const result = await getFinancialInsights(currentExpenses.slice(0, 15), currentSettings);
    if (result) setAiInsight(result);
    setAiLoading(false);
  }, []);

  useEffect(() => {
    if (expenses.length > 0) triggerAIUpdate(expenses, settings);
  }, []);

  return (
    <div className="min-h-screen p-4 md:p-8 max-w-6xl mx-auto space-y-8 pb-24">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">
            📊 জুয়েল রানার ট্র্যাকার
          </h1>
          <p className="text-slate-500 font-medium">আপনার ব্যাংক ও খরচের স্মার্ট হিসাব</p>
        </div>
        <button 
          onClick={() => setShowSettings(!showSettings)}
          className="bg-white px-5 py-2.5 rounded-xl shadow-sm border border-slate-200 text-slate-700 hover:bg-slate-50 transition-all flex items-center gap-2 font-bold"
        >
          <Settings size={18} /> সেটিংস ও ব্যাংক
        </button>
      </header>

      {/* Settings & Bank Management Modal */}
      {showSettings && (
        <div className="bg-white p-6 rounded-2xl shadow-2xl border border-indigo-100 animate-in fade-in zoom-in duration-300">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold text-slate-800">ব্যাংক ও বাজেট সেটিংস</h2>
            <button onClick={() => setShowSettings(false)} className="text-slate-400 hover:text-slate-600">✕</button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Limit Settings */}
            <div className="space-y-4">
              <h3 className="font-bold text-slate-700 flex items-center gap-2">🎯 দৈনিক খরচ সীমা</h3>
              <div className="flex gap-2">
                <input 
                  type="number" 
                  value={newDailyLimit}
                  onChange={e => setNewDailyLimit(e.target.value)}
                  className="flex-1 px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="দৈনিক লিমিট লিখুন"
                />
                <button 
                  onClick={updateDailyLimit}
                  className="bg-slate-800 text-white px-4 py-2 rounded-xl font-bold hover:bg-slate-900 transition-colors"
                >
                  সেভ
                </button>
              </div>
            </div>

            {/* Bank Management */}
            <div className="space-y-4">
              <h3 className="font-bold text-slate-700 flex items-center gap-2">🏦 ব্যাংক/অ্যাকাউন্ট যোগ করুন</h3>
              <div className="flex flex-col gap-2">
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    value={newBankName}
                    onChange={e => setNewBankName(e.target.value)}
                    placeholder="ব্যাংকের নাম (উদা: বিকাশ)"
                    className="flex-1 px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                  <input 
                    type="number" 
                    value={newBankBalance}
                    onChange={e => setNewBankBalance(e.target.value)}
                    placeholder="ব্যালেন্স"
                    className="w-24 px-4 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                  <button 
                    onClick={addBank}
                    className="bg-indigo-600 text-white p-2 rounded-xl hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100"
                  >
                    <Plus size={24} />
                  </button>
                </div>
                
                <div className="mt-4 space-y-2 max-h-48 overflow-y-auto pr-2">
                  {settings.banks.map(bank => (
                    <div key={bank.id} className="flex justify-between items-center bg-slate-50 p-3 rounded-xl border border-slate-100">
                      <div>
                        <p className="font-bold text-slate-800">{bank.name}</p>
                        <p className="text-sm text-slate-500">{BDT_SYMBOL} {bank.balance.toLocaleString()}</p>
                      </div>
                      <button 
                        onClick={() => deleteBank(bank.id)}
                        className="text-rose-400 hover:text-rose-600 p-2"
                        disabled={settings.banks.length <= 1}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Dashboard Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <DashboardCard 
          title="মোট ব্যালেন্স (সব ব্যাংক)" 
          amount={totalBankBalance} 
          variant="success" 
        />
        <DashboardCard 
          title="আজকের খরচ" 
          amount={todayTotal} 
          variant={isLimitExceeded ? 'danger' : 'primary'}
          className={isLimitExceeded ? 'animate-shake' : ''}
          subtitle={isLimitExceeded ? '⚠️ আপনি সীমা অতিক্রম করেছেন!' : 'বাজেটের মধ্যে আছে'}
        />
        <DashboardCard 
          title="দৈনিক বাজেট লিমিট" 
          amount={settings.dailyLimit} 
          variant="warning" 
        />
      </div>

      {/* Bank Breakdown Carousel/Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {settings.banks.map(bank => (
          <div key={bank.id} className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-3">
            <div className="bg-indigo-50 p-2 rounded-lg text-indigo-600">
              <CreditCard size={20} />
            </div>
            <div>
              <p className="text-xs text-slate-500 font-medium truncate w-24" title={bank.name}>{bank.name}</p>
              <p className="font-bold text-slate-800">{BDT_SYMBOL}{bank.balance.toLocaleString()}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Form & Insights */}
        <div className="lg:col-span-1 space-y-8">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h2 className="text-xl font-bold mb-6 text-slate-800 flex items-center gap-2">
              ➕ নতুন খরচ যোগ করুন
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">খরচের নাম</label>
                <input 
                  type="text" 
                  value={expenseName}
                  onChange={e => setExpenseName(e.target.value)}
                  placeholder="উদা: ডিনার"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-600 mb-1">পরিমাণ ({BDT_SYMBOL})</label>
                  <input 
                    type="number" 
                    value={expenseAmount}
                    onChange={e => setExpenseAmount(e.target.value)}
                    placeholder="0"
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-600 mb-1">বিভাগ</label>
                  <select 
                    value={expenseCategory}
                    onChange={e => setExpenseCategory(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none bg-white"
                  >
                    {CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-600 mb-1">ব্যাংক নির্বাচন করুন</label>
                <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto p-1">
                  {settings.banks.map(bank => (
                    <button
                      key={bank.id}
                      onClick={() => setSelectedBankId(bank.id)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all truncate ${
                        selectedBankId === bank.id 
                        ? 'bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-100' 
                        : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-300'
                      }`}
                    >
                      {bank.name}
                    </button>
                  ))}
                </div>
              </div>
              <button 
                onClick={addExpense}
                className="w-full bg-slate-800 text-white py-4 rounded-xl font-bold text-lg hover:bg-slate-900 transition-all shadow-xl shadow-slate-200 active:scale-95 flex items-center justify-center gap-2"
              >
                <Wallet size={20} /> খরচ যোগ করুন
              </button>
            </div>
          </div>

          <AIInsightBox insight={aiInsight} loading={aiLoading} />
        </div>

        {/* Right Column: Visualization & History */}
        <div className="lg:col-span-2 space-y-8">
          <SpendingChart expenses={expenses} />

          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">📜 সাম্প্রতিক খরচসমূহ</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 text-sm font-semibold">
                    <th className="px-6 py-4">তারিখ</th>
                    <th className="px-6 py-4">বিবরণ/ব্যাংক</th>
                    <th className="px-6 py-4">বিভাগ</th>
                    <th className="px-6 py-4 text-right">পরিমাণ</th>
                    <th className="px-6 py-4"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {expenses.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-slate-400 italic">এখনো কোন খরচ নেই</td>
                    </tr>
                  ) : (
                    expenses.slice(0, 20).map(e => {
                      const bank = settings.banks.find(b => b.id === e.bankId);
                      return (
                        <tr key={e.id} className="hover:bg-slate-50 transition-colors group">
                          <td className="px-6 py-4 text-sm text-slate-500">{e.date}</td>
                          <td className="px-6 py-4">
                            <p className="font-medium text-slate-800">{e.name}</p>
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">
                              🏦 {bank?.name || 'অজানা ব্যাংক'}
                            </p>
                          </td>
                          <td className="px-6 py-4">
                            <span className="px-2 py-1 rounded-lg bg-indigo-50 text-indigo-600 text-[10px] font-bold">
                              {e.category}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right font-bold text-slate-900">
                            {BDT_SYMBOL} {e.amount.toLocaleString()}
                          </td>
                          <td className="px-6 py-4 text-right">
                            <button 
                              onClick={() => deleteExpense(e.id)}
                              className="text-rose-400 hover:text-rose-600 opacity-0 group-hover:opacity-100 transition-opacity p-2"
                            >
                              <Trash2 size={16} />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
