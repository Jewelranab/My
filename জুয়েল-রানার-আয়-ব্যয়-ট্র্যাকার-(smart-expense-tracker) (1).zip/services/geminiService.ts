
import { GoogleGenAI, Type } from "@google/genai";
import { Expense, UserSettings } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getFinancialInsights = async (expenses: Expense[], settings: UserSettings) => {
  if (expenses.length === 0) return null;

  const expenseSummary = expenses.map(e => `${e.name}: ${e.amount} (${e.category})`).join(', ');
  const bankSummary = settings.banks.map(b => `${b.name}: ${b.balance} BDT`).join(', ');
  
  const prompt = `
    তুমি একজন ব্যক্তিগত আর্থিক উপদেষ্টা। নিচের তথ্যের ভিত্তিতে ব্যবহারকারীকে বাংলায় পরামর্শ দাও।
    ব্যবহারকারীর বর্তমান ব্যাংক অ্যাকাউন্টসমূহ: ${bankSummary}
    দৈনিক খরচের সীমা: ${settings.dailyLimit} BDT।
    সাম্প্রতিক খরচগুলো: ${expenseSummary}
    
    তোমার পরামর্শে নিচের বিষয়গুলো অন্তর্ভুক্ত করো:
    ১. খরচের ধরণের একটি সংক্ষিপ্ত সারসংক্ষেপ।
    ২. টাকা বাঁচানোর জন্য ৩টি বাস্তবসম্মত পরামর্শ।
    ৩. বর্তমান পরিস্থিতির একটি স্ট্যাটাস (ভাল, সতর্কবার্তা, বা জটিল)।
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            suggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            status: {
              type: Type.STRING,
              description: "Must be 'good', 'warning', or 'critical'"
            }
          },
          required: ["summary", "suggestions", "status"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("AI Insights Error:", error);
    return null;
  }
};
