
export interface BankAccount {
  id: string;
  name: string;
  balance: number;
}

export interface Expense {
  id: string;
  name: string;
  amount: number;
  category: string;
  bankId: string; // কোন ব্যাংক থেকে খরচ হয়েছে
  date: string;
}

export interface UserSettings {
  banks: BankAccount[];
  dailyLimit: number;
}

export interface AIInsight {
  summary: string;
  suggestions: string[];
  status: 'good' | 'warning' | 'critical';
}
