
export const CATEGORIES = [
  'খাদ্য',
  'পরিবহন',
  'বাজার',
  'বিল ও রিচার্জ',
  'কেনাকাটা',
  'বিনোদন',
  'অন্যান্য'
];

export const BDT_SYMBOL = '৳';
